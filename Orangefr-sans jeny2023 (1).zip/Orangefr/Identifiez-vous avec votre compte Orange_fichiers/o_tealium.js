<!-- Tealium Tracking Script  --> 
localStorage && localStorage.setItem("tealium-activate", "true");
localStorage && localStorage.setItem("tealium-activate.sync", "true");
<!-- End of Tealium Tracking Script -->
if(location.hostname.match(/actu|auto|cineday|femmes|finance|meteo|sports|tv\.|video-streaming|presse|passjeuxfamille|musique|cinema/)){
    if(o_confCommon && o_confCommon.tracking){
        o_confCommon.tracking.disableDOMAutoTrack = true;
    }
}